#pragma once

void mf(int ny, int nx, int hy, int hx, const float *in, float *out);
